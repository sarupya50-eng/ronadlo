require('dotenv').config();
const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const { exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);
const fs = require('fs');
const path = require('path');

const PREFIX = '!';
const ADMIN_IDS = (process.env.ADMIN_IDS || '').split(',').filter(Boolean);
const DB_PATH = path.join(__dirname, 'instances.json');

// ---- simple JSON "db" for tracking instances ----
function loadDB() {
  if (!fs.existsSync(DB_PATH)) fs.writeFileSync(DB_PATH, '{}');
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}
function saveDB(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

// ---- helper: generate random password ----
function genPassword(len = 14) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%';
  let out = '';
  for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

// ---- helper: run shell command safely ----
async function run(cmd) {
  try {
    const { stdout, stderr } = await execAsync(cmd, { timeout: 120000 });
    return { ok: true, stdout, stderr };
  } catch (err) {
    return { ok: false, stdout: err.stdout, stderr: err.stderr || err.message };
  }
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

client.once('ready', () => {
  console.log(`Logged in as ${client.user.tag}`);
});

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  if (!message.content.startsWith(PREFIX)) return;

  const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const cmd = args.shift().toLowerCase();

  const isAdmin = ADMIN_IDS.includes(message.author.id);

  // ---- !createvps <name> <cpu> <ram_gb> <disk_gb> [@user] ----
  if (cmd === 'createvps') {
    if (!isAdmin) return message.reply('You are not authorized to run this command.');

    const [name, cpu, ramGb, diskGb] = args;
    if (!name || !cpu || !ramGb || !diskGb) {
      return message.reply(
        'Usage: `!createvps <name> <cpu_cores> <ram_gb> <disk_gb>`\nExample: `!createvps john-vps1 2 4 40`'
      );
    }

    // basic name validation - lxc requires lowercase alphanumeric + hyphens
    if (!/^[a-z0-9-]+$/.test(name)) {
      return message.reply('Instance name must be lowercase letters, numbers, and hyphens only.');
    }

    const db = loadDB();
    if (db[name]) return message.reply(`An instance named \`${name}\` already exists.`);

    const statusMsg = await message.reply(`Creating instance \`${name}\`... this may take a minute.`);

    const launch = await run(`lxc launch ubuntu:22.04 ${name}`);
    if (!launch.ok) {
      return statusMsg.edit(`Failed to launch instance:\n\`\`\`${launch.stderr}\`\`\``);
    }

    await run(`lxc config set ${name} limits.cpu ${cpu}`);
    await run(`lxc config set ${name} limits.memory ${ramGb}GB`);
    await run(`lxc config device override ${name} root size=${diskGb}GB`);

    // wait a few seconds for networking/cloud-init inside container
    await new Promise((r) => setTimeout(r, 8000));

    // set root password
    const password = genPassword();
    const setPass = await run(
      `lxc exec ${name} -- bash -c "echo root:${password} | chpasswd"`
    );

    // enable root SSH login with password auth
    await run(
      `lxc exec ${name} -- bash -c "sed -i 's/#PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config && sed -i 's/PermitRootLogin prohibit-password/PermitRootLogin yes/' /etc/ssh/sshd_config && sed -i 's/#PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config && systemctl restart ssh"`
    );

    // get IP
    const ipResult = await run(`lxc list ${name} -c 4 --format csv`);
    const ip = ipResult.stdout ? ipResult.stdout.split(' ')[0].trim() : 'pending (run !vpsinfo)';

    db[name] = {
      name,
      cpu,
      ramGb,
      diskGb,
      password,
      createdAt: new Date().toISOString(),
      ownerId: message.author.id,
    };
    saveDB(db);

    const embed = new EmbedBuilder()
      .setTitle(`VPS Instance Created: ${name}`)
      .setColor(0x00c896)
      .addFields(
        { name: 'CPU', value: `${cpu} core(s)`, inline: true },
        { name: 'RAM', value: `${ramGb} GB`, inline: true },
        { name: 'Disk', value: `${diskGb} GB`, inline: true },
        { name: 'IP Address', value: ip || 'pending', inline: false },
        { name: 'Root Password', value: `||${password}||`, inline: false }
      )
      .setFooter({ text: 'SSH: ssh root@<ip>' });

    await statusMsg.edit({ content: null, embeds: [embed] });
  }

  // ---- !deletevps <name> ----
  else if (cmd === 'deletevps') {
    if (!isAdmin) return message.reply('You are not authorized to run this command.');
    const [name] = args;
    if (!name) return message.reply('Usage: `!deletevps <name>`');

    const db = loadDB();
    if (!db[name]) return message.reply(`No instance named \`${name}\` found.`);

    const del = await run(`lxc delete ${name} --force`);
    if (!del.ok) return message.reply(`Failed to delete: \`\`\`${del.stderr}\`\`\``);

    delete db[name];
    saveDB(db);
    message.reply(`Instance \`${name}\` deleted.`);
  }

  // ---- !listvps ----
  else if (cmd === 'listvps') {
    const db = loadDB();
    const names = Object.keys(db);
    if (names.length === 0) return message.reply('No instances created yet.');

    const listResult = await run(`lxc list --format csv -c n,s,4`);
    const lines = listResult.stdout ? listResult.stdout.trim().split('\n') : [];

    const embed = new EmbedBuilder().setTitle('VPS Instances').setColor(0x5865f2);

    for (const line of lines) {
      const [n, state, ip] = line.split(',');
      const meta = db[n];
      if (!meta) continue;
      embed.addFields({
        name: n,
        value: `State: ${state} | IP: ${ip || 'n/a'} | ${meta.cpu} vCPU / ${meta.ramGb}GB RAM / ${meta.diskGb}GB disk`,
      });
    }

    message.reply({ embeds: [embed] });
  }

  // ---- !vpsinfo <name> ----
  else if (cmd === 'vpsinfo') {
    const [name] = args;
    if (!name) return message.reply('Usage: `!vpsinfo <name>`');

    const db = loadDB();
    const meta = db[name];
    if (!meta) return message.reply(`No instance named \`${name}\` found.`);

    // only owner or admin can see password
    if (meta.ownerId !== message.author.id && !isAdmin) {
      return message.reply('You do not have permission to view this instance.');
    }

    const ipResult = await run(`lxc list ${name} -c 4 --format csv`);
    const ip = ipResult.stdout ? ipResult.stdout.split(' ')[0].trim() : 'pending';

    const embed = new EmbedBuilder()
      .setTitle(`VPS Info: ${name}`)
      .setColor(0x00c896)
      .addFields(
        { name: 'CPU', value: `${meta.cpu} core(s)`, inline: true },
        { name: 'RAM', value: `${meta.ramGb} GB`, inline: true },
        { name: 'Disk', value: `${meta.diskGb} GB`, inline: true },
        { name: 'IP Address', value: ip, inline: false },
        { name: 'Root Password', value: `||${meta.password}||`, inline: false }
      );

    message.reply({ embeds: [embed] });
  }

  // ---- !vpshelp ----
  else if (cmd === 'vpshelp') {
    const embed = new EmbedBuilder()
      .setTitle('VPS Bot Commands')
      .setColor(0x5865f2)
      .setDescription(
        [
          '`!createvps <name> <cpu> <ram_gb> <disk_gb>` - Create a new VPS (admin only)',
          '`!deletevps <name>` - Delete a VPS (admin only)',
          '`!listvps` - List all VPS instances',
          '`!vpsinfo <name>` - Get IP + password for your instance',
        ].join('\n')
      );
    message.reply({ embeds: [embed] });
  }
});

client.login(process.env.DISCORD_TOKEN);
