# LXD VPS Bot

Discord bot to provision VPS instances via LXD on a single VPS. Runs directly
on the same machine as LXD and shells out to the `lxc` CLI.

## Setup

1. Copy `.env.example` to `.env` and fill in:
   - `DISCORD_TOKEN` — from the Discord Developer Portal
   - `ADMIN_IDS` — your Discord user ID(s), comma separated (only admins can create/delete VPS)

2. Enable the **Message Content Intent** for your bot in the Developer Portal
   (Bot tab -> Privileged Gateway Intents).

3. Install dependencies:
   ```bash
   npm install
   ```

4. Run the bot (must run as root or a user with lxc/sudo permissions):
   ```bash
   node index.js
   ```

   For persistence, use pm2:
   ```bash
   npm install -g pm2
   pm2 start index.js --name lxd-vps-bot
   pm2 save
   ```

## Commands

- `!createvps <name> <cpu> <ram_gb> <disk_gb>` — create a VPS (admin only)
- `!deletevps <name>` — delete a VPS (admin only)
- `!listvps` — list all instances with state + IP
- `!vpsinfo <name>` — get IP + root password (owner or admin only)
- `!vpshelp` — show command list

## Notes

- Instance data (name, specs, password, owner) is stored in `instances.json`
  in this folder. Back this up or migrate to a real database later.
- Root password auth over SSH is enabled per-instance. If you want to lock
  this down later, switch to SSH-keypair provisioning instead.
- `!createvps` is currently manual — you or another admin runs it after a
  customer pays. Paymenter webhook automation can be added later to call
  this automatically.
